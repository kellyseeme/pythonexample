#!/usr/bin/env python

def foo():
    print 'foo function'

if __name__ == '__main__':
    foo()
